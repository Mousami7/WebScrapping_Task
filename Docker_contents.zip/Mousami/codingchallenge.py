
import requests  # Importing the requests library to make HTTP requests
from bs4 import BeautifulSoup  # Importing BeautifulSoup for HTML parsing

url = "https://www.lucernefestival.ch/en/program/summer-festival-24"  # URL of the webpage to scrape provided in the coding challenge

# Fetch the HTML content from the URL
response = requests.get(url)
html_content = response.text

# Parse the HTML content using BeautifulSoup
soup = BeautifulSoup(html_content, 'html.parser')


# Function to extract event details
def extract_event_details(soup):
    """
    Extract event details from the BeautifulSoup object.

    Args:
        soup (BeautifulSoup): The BeautifulSoup object containing parsed HTML content.

    Returns:
        list: A list of dictionaries, each containing event details.
    """
    event_details = []  # List to store extracted event details
    
    # Extracting event titles
    event_titles = soup.find_all('div', class_='event-content')
    for title in event_titles:
        event_details.append(title.text.strip())  # Append event title to the list
    
    return event_details

# Extract event details
event_details = extract_event_details(soup)

# Print or process the extracted event details
for event in event_details:
    print(event)  # Print each event title




import re  # Importing the re module for regular expression operations

all_events = []  # List to store all extracted event details

def extract_event_details(input_text):
    """
    Extract event details from the input text using regular expressions.

    Args:
        input_text (str): The text containing event details.

    Returns:
        dict: A dictionary containing the extracted event details.
    """
    def extract_text_between_keywords(text, keyword1, keyword2):
        """
        Extract text between two keywords using regular expressions.

        Args:
            text (str): The input text.
            keyword1 (str): The starting keyword.
            keyword2 (str): The ending keyword.

        Returns:
            str: The text between the two keywords, or None if not found.
        """
        pattern = re.compile(f'{re.escape(keyword1)}(.*?){re.escape(keyword2)}', re.DOTALL)
        match = pattern.search(text)

        if match:
            return match.group(1).strip()
        else:
            return None

    # Define start and end keywords for extraction
    start_keyword = "Date and Venue"
    end_keyword = "Program"

    # Extract different parts of the event details using the defined keywords
    result = extract_text_between_keywords(input_text, start_keyword, end_keyword)
    result_artist = extract_text_between_keywords(input_text, '|', 'Date and Venue')
    result_works = extract_text_between_keywords(input_text, 'Program', 'Summer')
    result_title = extract_text_between_keywords(input_text, '\n', '|')  # Extracting title from the first line

    if result:
        # Split the result into tokens using '|' as delimiter
        tokens = result.split('|')

        # Remove leading and trailing whitespaces from each token
        tokens = [token.strip() for token in tokens if token]

        # Create the event dictionary
        event_dict = {
            "Date": tokens[0],
            "Time": tokens[1],
            "Venue": tokens[2],
            "Title": result_title.splitlines()[0],  # Use the extracted title
            "Artist_Name": result_artist,
            "Works": result_works
        }

        return event_dict
    else:

        event_dict = {
            "Date": "",
            "Time": "",
            "Venue": "",
            "Title": "",  # Use the extracted title
            "Artist_Name": "",
            "Works": ""
        }
        return event_dict


# Iterate over each event detail and extract its details
for event in event_details:
    # Extract event details using the defined function
    event_dict = extract_event_details(event)
    
    # Append the extracted event details to the list
    all_events.append(event_dict)
    
    # Print the extracted event details
    print(event_dict)
    print(len((event_dict)))





import re  # Importing the re module for regular expression operations

all_events = []  # List to store all extracted event details

def extract_event_details(input_text):
    """
    Extract event details from the input text using regular expressions.

    Args:
        input_text (str): The text containing event details.

    Returns:
        dict: A dictionary containing the extracted event details.
    """
    def extract_text_between_keywords(text, keyword1, keyword2):
        """
        Extract text between two keywords using regular expressions.

        Args:
            text (str): The input text.
            keyword1 (str): The starting keyword.
            keyword2 (str): The ending keyword.

        Returns:
            str: The text between the two keywords, or None if not found.
        """
        pattern = re.compile(f'{re.escape(keyword1)}(.*?){re.escape(keyword2)}', re.DOTALL)
        match = pattern.search(text)

        if match:
            return match.group(1).strip()
        else:
            return None

    # Define start and end keywords for extraction
    start_keyword = "Date and Venue"
    end_keyword = "Program"

    # Extract different parts of the event details using the defined keywords
    result = extract_text_between_keywords(input_text, start_keyword, end_keyword)
    result_artist = extract_text_between_keywords(input_text, '|', 'Date and Venue')
    result_works = extract_text_between_keywords(input_text, 'Program', 'Summer')
    result_title = extract_text_between_keywords(input_text, '\n', '|')  # Extracting title from the first line

    if result:
        # Split the result into tokens using '|' as delimiter
        tokens = result.split('|')

        # Remove leading and trailing whitespaces from each token
        tokens = [token.strip() for token in tokens if token]

        # Create the event dictionary
        event_dict = {
            "Date": tokens[0],
            "Time": tokens[1],
            "Venue": tokens[2],
            "Title": result_title.splitlines()[0],  # Use the extracted title
            "Artist_Name": result_artist,
            "Works": result_works
        }

        return event_dict
    else:
        event_dict = {
            "Date": "",
            "Time": "",
            "Venue": "",
            "Title": "",  # Use the extracted title
            "Artist_Name": "",
            "Works": ""
        }
        return event_dict


# Iterate over each event detail and extract its details
for event in event_details:
    # Extract event details using the defined function
    event_dict = extract_event_details(event)
    
    # Append the extracted event details to the list
    all_events.append(event_dict)
    
    # Print the extracted event details
    print(event_dict)



'''

printing all_events list od dictionaries which contains "Date","Time","Venue","Title",
"Artist_Name" and "Works" as key elements and corresponding values are fetched from the webscript


'''

all_events 




import requests  # Importing the requests library to make HTTP requests
from bs4 import BeautifulSoup  # Importing BeautifulSoup for HTML parsing

# Fetch HTML content from the URL
response = requests.get(url)
html_content = response.text

# Parse HTML content using BeautifulSoup
soup = BeautifulSoup(html_content, 'html.parser')

# Find all <picture> elements with class 'clr-sec'
li_elements = soup.find_all('picture', class_='clr-sec')

# Filter out None values from all_events
filtered_events = [event for event in all_events if event is not None]

# Determine the minimum length to avoid IndexError
min_length = min(len(filtered_events), len(li_elements))

# Iterate over the minimum length and update image links
for i in range(min_length):
    try:
        img_element = li_elements[i].find('source')  # Find <source> element within <picture>

        if img_element:
            img_path = "https://www.lucernefestival.ch" + img_element['srcset']  # Construct image URL
            filtered_events[i]['ImageLink'] = img_path  # Update image link in event dictionary
        else:
            filtered_events[i]['ImageLink'] = 'NOT AVAILABLE'  # Set image link as 'NOT AVAILABLE' if <source> not found
    except Exception as e:
        print("Error:", e)  # Print any encountered errors

# Update original all_events list with filtered_events
all_events = filtered_events



'''

printing all_events list of dictionaries which contains "Date","Time","Venue","Title",
"Artist_Name","Works" with added "ImageLink" as a new key element and corresponding values are fetched from the webscript


'''

print(all_events)



import psycopg2

# Connect to PostgreSQL database
import psycopg2

try:
    conn = psycopg2.connect(
        dbname="FutureDemand",  # Name of the database
        user="postgres",        # Username for database connection
        password="Krishna7@",   # Password for database connection
        host="192.168.178.57",       # Hostname of the PostgreSQL server
        port="5432"             # Port number for database connection
        
    )

except psycopg2.OperationalError as e:
    print(f"Error connecting to the database: {e}")



conn = psycopg2.connect(
    dbname="FutureDemand",  # Name of the database
    user="postgres",        # Username for database connection
    password="Krishna7@",   # Password for database connection
    host="192.168.178.57",       # Hostname of the PostgreSQL server
    port="5432"             # Port number for database connection
)

# Create a cursor object
cur = conn.cursor()

# Create CodingChallenge schema
cur.execute("CREATE SCHEMA IF NOT EXISTS CodingChallenge")

# Define schema and create events table
cur.execute("""
    CREATE TABLE IF NOT EXISTS CodingChallenge.events (
        id SERIAL PRIMARY KEY,
        date TEXT,
        time TEXT,
        venue TEXT,
        title TEXT,
        artist_name TEXT,
        works TEXT,
        image_link TEXT
    )
""")

# Iterate over all events and insert them into the PostgreSQL database
for event_data in all_events:
    cur.execute("""
    INSERT INTO CodingChallenge.events (date, time, venue, title, artist_name, works, image_link)
    VALUES (%s, %s, %s, %s, %s, %s, %s)
""", (
    event_data["Date"],
    event_data["Time"],
    event_data["Venue"],
    event_data["Title"],
    event_data["Artist_Name"],
    event_data["Works"],
    event_data["ImageLink"]
))

# Commit the transaction
conn.commit()

# Close cursor and connection
cur.close()
conn.close()


# ### Checking the Versions:-



import sys
print(sys.version)




import bs4
print(bs4.__version__)


import psycopg2
print(psycopg2.__version__)



import requests
print(requests.__version__)







